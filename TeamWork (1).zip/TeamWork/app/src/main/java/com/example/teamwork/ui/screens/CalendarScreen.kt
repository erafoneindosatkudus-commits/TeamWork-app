package com.example.teamwork.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.teamwork.data.TaskStatus
import com.example.teamwork.ui.AppViewModel
import com.example.teamwork.ui.formatDateTime
import com.example.teamwork.ui.formatDay
import com.example.teamwork.ui.formatTime
import com.example.teamwork.ui.pickDateTime

private data class AgendaItem(
    val key: String,
    val title: String,
    val subtitle: String,
    val at: Long,
    val isTask: Boolean,
    val eventId: String?
)

@Composable
fun CalendarScreen(vm: AppViewModel) {
    val events by vm.events.collectAsStateWithLifecycle()
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    var showAdd by remember { mutableStateOf(false) }

    val agenda = buildList {
        events.forEach {
            add(AgendaItem("e${it.id}", it.title, it.description, it.startAt, false, it.id))
        }
        tasks.filter { it.dueAt > 0 && it.statusEnum != TaskStatus.DONE }.forEach {
            add(AgendaItem("t${it.id}", it.title, "Tenggat tugas", it.dueAt, true, null))
        }
    }.sortedBy { it.at }
    val grouped = agenda.groupBy { formatDay(it.at) }

    Box(Modifier.fillMaxSize()) {
        if (agenda.isEmpty()) {
            Text(
                "Belum ada jadwal",
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                grouped.forEach { (day, dayItems) ->
                    item(key = "h$day") {
                        Text(
                            day,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                    items(dayItems, key = { it.key }) { item ->
                        AgendaRow(item, onDelete = { item.eventId?.let(vm::deleteEvent) })
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Tambah jadwal") }
    }

    if (showAdd) {
        AddEventDialog(
            onDismiss = { showAdd = false },
            onSave = { title, desc, at ->
                vm.addEvent(title, desc, at)
                showAdd = false
            }
        )
    }
}

@Composable
private fun AgendaRow(item: AgendaItem, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                formatTime(item.at),
                style = MaterialTheme.typography.titleMedium,
                color = if (item.isTask) MaterialTheme.colorScheme.tertiary
                else MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 14.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.SemiBold)
                if (item.subtitle.isNotBlank()) {
                    Text(item.subtitle, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (!item.isTask) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus jadwal")
                }
            }
        }
    }
}

@Composable
private fun AddEventDialog(
    onDismiss: () -> Unit,
    onSave: (title: String, description: String, startAt: Long) -> Unit
) {
    val context = LocalContext.current
    var title by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var startAt by rememberSaveable { mutableLongStateOf(0L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Jadwal baru") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Judul (mis. Rapat mingguan)") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Keterangan (opsional)") },
                    minLines = 2
                )
                OutlinedButton(
                    onClick = { pickDateTime(context) { startAt = it } },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (startAt > 0) formatDateTime(startAt) else "Pilih tanggal & jam")
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(title, description, startAt) },
                enabled = title.isNotBlank() && startAt > 0
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
