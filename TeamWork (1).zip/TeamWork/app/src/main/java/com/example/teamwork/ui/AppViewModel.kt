package com.example.teamwork.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.teamwork.notify.ReminderWorker
import com.google.firebase.messaging.FirebaseMessaging
import com.example.teamwork.data.Team
import com.example.teamwork.data.TaskStatus
import com.example.teamwork.data.TeamEvent
import com.example.teamwork.data.TeamFile
import com.example.teamwork.data.TeamMessage
import com.example.teamwork.data.TeamRepository
import com.example.teamwork.data.TeamTask
import com.example.teamwork.data.UserProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface Session {
    data object Loading : Session
    data object SignedOut : Session
    data class NeedsTeam(val profile: UserProfile) : Session
    data class InTeam(val profile: UserProfile) : Session
}

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = TeamRepository()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    val session: StateFlow<Session> = repo.authUser()
        .flatMapLatest { user ->
            if (user == null) {
                flowOf<Session>(Session.SignedOut)
            } else {
                repo.profile(user.uid).map<UserProfile, Session> { p ->
                    val profile = p.copy(
                        uid = user.uid,
                        name = p.name.ifBlank { user.email?.substringBefore('@') ?: "Anggota" }
                    )
                    if (profile.teamId.isBlank()) Session.NeedsTeam(profile)
                    else Session.InTeam(profile)
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Session.Loading)

    private val teamId: Flow<String?> = session
        .map { (it as? Session.InTeam)?.profile?.teamId }
        .distinctUntilChanged()

    val team: StateFlow<Team?> = teamId
        .flatMapLatest { id -> if (id == null) flowOf<Team?>(null) else repo.team(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val tasks: StateFlow<List<TeamTask>> = teamId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.tasks(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chat: StateFlow<List<TeamMessage>> = teamId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val events: StateFlow<List<TeamEvent>> = teamId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.events(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val files: StateFlow<List<TeamFile>> = teamId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.files(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Langganan notifikasi push per tim + pengingat tenggat lokal.
        viewModelScope.launch {
            var previous: String? = null
            teamId.collect { id ->
                val old = previous
                if (old != null && old != id) {
                    FirebaseMessaging.getInstance().unsubscribeFromTopic("team_$old")
                }
                if (id != null) {
                    FirebaseMessaging.getInstance().subscribeToTopic("team_$id")
                    ReminderWorker.schedule(getApplication())
                } else {
                    ReminderWorker.cancel(getApplication())
                }
                previous = id
            }
        }
    }

    // ---------- Aksi akun & tim ----------

    fun signIn(email: String, password: String) = run {
        if (email.isBlank() || password.isBlank()) {
            toast("Email dan kata sandi wajib diisi")
        } else {
            action { repo.signIn(email, password) }
        }
    }

    fun signUp(name: String, email: String, password: String) = run {
        when {
            name.isBlank() || email.isBlank() -> toast("Nama dan email wajib diisi")
            password.length < 6 -> toast("Kata sandi minimal 6 karakter")
            else -> action { repo.signUp(name, email, password) }
        }
    }

    fun signOut() = repo.signOut()

    fun createTeam(name: String) {
        if (name.isBlank()) toast("Nama tim wajib diisi") else action { repo.createTeam(name) }
    }

    fun joinTeam(code: String) {
        if (code.isBlank()) toast("Masukkan kode tim") else action { repo.joinTeam(code) }
    }

    fun leaveTeam() = action { repo.leaveTeam() }

    // ---------- Aksi data tim ----------

    fun addTask(title: String, description: String, assignee: String, dueAt: Long) =
        inTeam { teamId, me -> repo.addTask(teamId, title, description, assignee, dueAt, me) }

    fun updateTask(task: TeamTask, title: String, description: String, assignee: String, dueAt: Long) =
        inTeam { teamId, _ -> repo.updateTask(teamId, task.id, title, description, assignee, dueAt) }

    fun setTaskStatus(task: TeamTask, status: TaskStatus) =
        inTeam { teamId, _ -> repo.setTaskStatus(teamId, task.id, status) }

    fun deleteTask(task: TeamTask) =
        inTeam { teamId, _ -> repo.deleteTask(teamId, task.id) }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        inTeam { teamId, me -> repo.sendMessage(teamId, text, me) }
    }

    fun addEvent(title: String, description: String, startAt: Long) =
        inTeam { teamId, me -> repo.addEvent(teamId, title, description, startAt, me) }

    fun deleteEvent(eventId: String) =
        inTeam { teamId, _ -> repo.deleteEvent(teamId, eventId) }

    fun uploadFile(uri: Uri, name: String, size: Long) =
        inTeam { teamId, me -> repo.uploadFile(teamId, uri, name, size, me) }

    fun deleteFile(file: TeamFile) =
        inTeam { teamId, _ -> repo.deleteFile(teamId, file) }

    // ---------- Util ----------

    private fun toast(message: String) {
        _messages.tryEmit(message)
    }

    private fun inTeam(block: suspend (teamId: String, me: UserProfile) -> Unit) {
        val me = (session.value as? Session.InTeam)?.profile ?: return
        action { block(me.teamId, me) }
    }

    private fun action(block: suspend () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast(e.localizedMessage ?: "Terjadi kesalahan")
            } finally {
                _busy.value = false
            }
        }
    }
}
