package com.example.teamwork.data

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class TeamRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {

    // ---------- Auth ----------

    fun authUser(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun signUp(name: String, email: String, password: String) {
        val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val uid = requireNotNull(result.user).uid
        db.collection("users").document(uid).set(
            mapOf(
                "uid" to uid,
                "name" to name.trim(),
                "email" to email.trim(),
                "teamId" to ""
            ),
            SetOptions.merge()
        ).await()
    }

    fun signOut() = auth.signOut()

    // ---------- Profil & tim ----------

    fun profile(uid: String): Flow<UserProfile> = callbackFlow {
        val reg = db.collection("users").document(uid).addSnapshotListener { snap, _ ->
            trySend(snap?.toObject(UserProfile::class.java) ?: UserProfile(uid = uid))
        }
        awaitClose { reg.remove() }
    }

    fun team(teamId: String): Flow<Team?> = callbackFlow {
        val reg = db.collection("teams").document(teamId).addSnapshotListener { snap, _ ->
            trySend(snap?.toObject(Team::class.java))
        }
        awaitClose { reg.remove() }
    }

    suspend fun createTeam(name: String) {
        val uid = requireNotNull(auth.currentUser).uid
        val code = generateCode()
        val teamRef = db.collection("teams").document()
        db.runBatch { batch ->
            batch.set(
                teamRef,
                mapOf(
                    "name" to name.trim(),
                    "code" to code,
                    "ownerUid" to uid,
                    "createdAt" to System.currentTimeMillis()
                )
            )
            batch.set(db.collection("teamCodes").document(code), mapOf("teamId" to teamRef.id))
            batch.set(
                db.collection("users").document(uid),
                mapOf("teamId" to teamRef.id),
                SetOptions.merge()
            )
        }.await()
    }

    suspend fun joinTeam(code: String) {
        val uid = requireNotNull(auth.currentUser).uid
        val snap = db.collection("teamCodes").document(code.trim().uppercase()).get().await()
        val teamId = snap.getString("teamId")
            ?: throw IllegalArgumentException("Kode tim tidak ditemukan")
        db.collection("users").document(uid)
            .set(mapOf("teamId" to teamId), SetOptions.merge()).await()
    }

    suspend fun leaveTeam() {
        val uid = requireNotNull(auth.currentUser).uid
        db.collection("users").document(uid)
            .set(mapOf("teamId" to ""), SetOptions.merge()).await()
    }

    // ---------- Tugas ----------

    fun tasks(teamId: String): Flow<List<TeamTask>> =
        sub(teamId, "tasks").orderBy("createdAt", Query.Direction.DESCENDING)
            .listen(TeamTask::class.java)

    suspend fun addTask(
        teamId: String,
        title: String,
        description: String,
        assignee: String,
        dueAt: Long,
        by: UserProfile
    ) {
        sub(teamId, "tasks").add(
            mapOf(
                "title" to title.trim(),
                "description" to description.trim(),
                "assignee" to assignee.trim(),
                "status" to TaskStatus.OPEN.name,
                "dueAt" to dueAt,
                "createdBy" to by.name,
                "createdByUid" to by.uid,
                "createdAt" to System.currentTimeMillis()
            )
        ).await()
    }

    suspend fun updateTask(
        teamId: String,
        taskId: String,
        title: String,
        description: String,
        assignee: String,
        dueAt: Long
    ) {
        sub(teamId, "tasks").document(taskId).update(
            mapOf(
                "title" to title.trim(),
                "description" to description.trim(),
                "assignee" to assignee.trim(),
                "dueAt" to dueAt
            )
        ).await()
    }

    suspend fun setTaskStatus(teamId: String, taskId: String, status: TaskStatus) {
        sub(teamId, "tasks").document(taskId).update("status", status.name).await()
    }

    suspend fun deleteTask(teamId: String, taskId: String) {
        sub(teamId, "tasks").document(taskId).delete().await()
    }

    // ---------- Chat ----------

    fun messages(teamId: String): Flow<List<TeamMessage>> =
        sub(teamId, "messages").orderBy("createdAt").limitToLast(200)
            .listen(TeamMessage::class.java)

    suspend fun sendMessage(teamId: String, text: String, by: UserProfile) {
        sub(teamId, "messages").add(
            mapOf(
                "text" to text.trim(),
                "senderUid" to by.uid,
                "senderName" to by.name,
                "createdAt" to System.currentTimeMillis()
            )
        ).await()
    }

    // ---------- Kalender ----------

    fun events(teamId: String): Flow<List<TeamEvent>> =
        sub(teamId, "events").orderBy("startAt").listen(TeamEvent::class.java)

    suspend fun addEvent(
        teamId: String,
        title: String,
        description: String,
        startAt: Long,
        by: UserProfile
    ) {
        sub(teamId, "events").add(
            mapOf(
                "title" to title.trim(),
                "description" to description.trim(),
                "startAt" to startAt,
                "createdBy" to by.name,
                "createdByUid" to by.uid
            )
        ).await()
    }

    suspend fun deleteEvent(teamId: String, eventId: String) {
        sub(teamId, "events").document(eventId).delete().await()
    }

    // ---------- File ----------

    fun files(teamId: String): Flow<List<TeamFile>> =
        sub(teamId, "files").orderBy("createdAt", Query.Direction.DESCENDING)
            .listen(TeamFile::class.java)

    suspend fun uploadFile(teamId: String, uri: Uri, name: String, size: Long, by: UserProfile) {
        val path = "teams/$teamId/${UUID.randomUUID()}_$name"
        val ref = storage.reference.child(path)
        ref.putFile(uri).await()
        val url = ref.downloadUrl.await().toString()
        sub(teamId, "files").add(
            mapOf(
                "name" to name,
                "url" to url,
                "storagePath" to path,
                "size" to size,
                "uploadedBy" to by.name,
                "createdAt" to System.currentTimeMillis()
            )
        ).await()
    }

    suspend fun deleteFile(teamId: String, file: TeamFile) {
        runCatching { storage.reference.child(file.storagePath).delete().await() }
        sub(teamId, "files").document(file.id).delete().await()
    }

    // ---------- Util ----------

    private fun sub(teamId: String, name: String): CollectionReference =
        db.collection("teams").document(teamId).collection(name)

    private fun <T : Any> Query.listen(type: Class<T>): Flow<List<T>> = callbackFlow {
        val reg = addSnapshotListener { snap, _ ->
            trySend(snap?.toObjects(type) ?: emptyList())
        }
        awaitClose { reg.remove() }
    }

    private fun generateCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..6).map { alphabet.random() }.joinToString("")
    }
}
