package com.example.teamwork.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.teamwork.data.UserProfile
import com.example.teamwork.ui.screens.AuthScreen
import com.example.teamwork.ui.screens.CalendarScreen
import com.example.teamwork.ui.screens.ChatScreen
import com.example.teamwork.ui.screens.FilesScreen
import com.example.teamwork.ui.screens.TasksScreen
import com.example.teamwork.ui.screens.TeamSetupScreen

@Composable
fun TeamWorkApp(vm: AppViewModel = viewModel()) {
    val session by vm.session.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (val s = session) {
                Session.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                Session.SignedOut -> AuthScreen(vm)
                is Session.NeedsTeam -> TeamSetupScreen(vm, s.profile)
                is Session.InTeam -> MainScaffold(vm, s.profile)
            }
        }
    }
}

private data class TabItem(val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold(vm: AppViewModel, profile: UserProfile) {
    val tabs = listOf(
        TabItem("Tugas", Icons.Default.Checklist),
        TabItem("Chat", Icons.Default.Chat),
        TabItem("Kalender", Icons.Default.CalendarMonth),
        TabItem("File", Icons.Default.Folder)
    )
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var menuOpen by remember { mutableStateOf(false) }
    var showCode by remember { mutableStateOf(false) }
    val team by vm.team.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                        Text(team?.name ?: "Tim", fontWeight = FontWeight.SemiBold)
                        Text(profile.name, style = MaterialTheme.typography.labelSmall)
                    }
                },
                actions = {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Kode undangan tim") },
                            onClick = { menuOpen = false; showCode = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Keluar dari tim") },
                            onClick = { menuOpen = false; vm.leaveTeam() }
                        )
                        DropdownMenuItem(
                            text = { Text("Keluar akun") },
                            onClick = { menuOpen = false; vm.signOut() }
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> TasksScreen(vm)
                1 -> ChatScreen(vm, profile)
                2 -> CalendarScreen(vm)
                else -> FilesScreen(vm)
            }
        }
    }

    if (showCode) {
        val code = team?.code.orEmpty()
        AlertDialog(
            onDismissRequest = { showCode = false },
            title = { Text("Kode undangan tim") },
            text = {
                Column {
                    Text("Bagikan kode ini agar anggota lain bisa bergabung:")
                    Text(
                        code,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(code))
                    showCode = false
                }) { Text("Salin") }
            },
            dismissButton = { TextButton(onClick = { showCode = false }) { Text("Tutup") } }
        )
    }
}
