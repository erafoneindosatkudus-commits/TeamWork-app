package com.example.teamwork.notify

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Menerima pesan data FCM yang dikirim Cloud Functions ke topik "team_<teamId>".
 * Pengirim sendiri tidak diberi notifikasi.
 */
class TeamMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val me = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val data = message.data
        if (data["senderUid"] == me) return

        val title = data["title"] ?: "TeamWork"
        val body = data["body"] ?: return
        Notifier.show(this, Notifier.CH_UPDATES, title, body)
    }
}
