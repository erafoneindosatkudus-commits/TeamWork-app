package com.example.teamwork.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.teamwork.data.TaskStatus
import com.example.teamwork.data.TeamTask
import com.example.teamwork.ui.AppViewModel
import com.example.teamwork.ui.formatDateTime
import com.example.teamwork.ui.pickDateTime

@Composable
fun TasksScreen(vm: AppViewModel) {
    val tasks by vm.tasks.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TeamTask?>(null) }
    val statuses = TaskStatus.entries
    val current = statuses[tab]
    val visible = tasks.filter { it.statusEnum == current }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                statuses.forEachIndexed { index, status ->
                    val count = tasks.count { it.statusEnum == status }
                    Tab(
                        selected = tab == index,
                        onClick = { tab = index },
                        text = {
                            Text("${status.label} ($count)", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    )
                }
            }

            if (visible.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Belum ada tugas di sini", color = MaterialTheme.colorScheme.outline)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        start = 16.dp, end = 16.dp, top = 12.dp, bottom = 88.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(visible, key = { it.id }) { task ->
                        TaskCard(
                            task = task,
                            onEdit = { editing = task },
                            onMove = { vm.setTaskStatus(task, it) },
                            onDelete = { vm.deleteTask(task) }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showAdd = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.Add, contentDescription = "Tambah tugas") }
    }

    if (showAdd) {
        TaskDialog(
            initial = null,
            onDismiss = { showAdd = false },
            onSave = { title, desc, assignee, due ->
                vm.addTask(title, desc, assignee, due)
                showAdd = false
            }
        )
    }

    editing?.let { task ->
        TaskDialog(
            initial = task,
            onDismiss = { editing = null },
            onSave = { title, desc, assignee, due ->
                vm.updateTask(task, title, desc, assignee, due)
                editing = null
            }
        )
    }
}

@Composable
private fun TaskCard(
    task: TeamTask,
    onEdit: () -> Unit,
    onMove: (TaskStatus) -> Unit,
    onDelete: () -> Unit
) {
    val status = task.statusEnum
    val statuses = TaskStatus.entries
    val prev = statuses.getOrNull(status.ordinal - 1)
    val next = statuses.getOrNull(status.ordinal + 1)

    Card(Modifier.fillMaxWidth().clickable(onClick = onEdit)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    task.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus tugas")
                }
            }
            if (task.description.isNotBlank()) {
                Text(task.description, style = MaterialTheme.typography.bodyMedium)
            }
            if (task.assignee.isNotBlank()) {
                Text("Untuk: ${task.assignee}", style = MaterialTheme.typography.labelMedium)
            }
            if (task.dueAt > 0) {
                Text(
                    "Tenggat: ${formatDateTime(task.dueAt)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (prev != null) {
                    OutlinedButton(onClick = { onMove(prev) }) { Text("← ${prev.label}") }
                }
                if (next != null) {
                    OutlinedButton(onClick = { onMove(next) }) { Text("${next.label} →") }
                }
            }
        }
    }
}

@Composable
private fun TaskDialog(
    initial: TeamTask?,
    onDismiss: () -> Unit,
    onSave: (title: String, description: String, assignee: String, dueAt: Long) -> Unit
) {
    val context = LocalContext.current
    var title by rememberSaveable { mutableStateOf(initial?.title.orEmpty()) }
    var description by rememberSaveable { mutableStateOf(initial?.description.orEmpty()) }
    var assignee by rememberSaveable { mutableStateOf(initial?.assignee.orEmpty()) }
    var dueAt by rememberSaveable { mutableLongStateOf(initial?.dueAt ?: 0L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Tugas baru" else "Edit tugas") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Judul tugas") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Deskripsi (opsional)") },
                    minLines = 2
                )
                OutlinedTextField(
                    value = assignee,
                    onValueChange = { assignee = it },
                    label = { Text("Ditugaskan ke (opsional)") },
                    singleLine = true
                )
                OutlinedButton(
                    onClick = { pickDateTime(context) { dueAt = it } },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (dueAt > 0) "Tenggat: ${formatDateTime(dueAt)}" else "Atur tenggat")
                }
                if (dueAt > 0) {
                    TextButton(onClick = { dueAt = 0L }) { Text("Hapus tenggat") }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(title, description, assignee, dueAt) },
                enabled = title.isNotBlank()
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
