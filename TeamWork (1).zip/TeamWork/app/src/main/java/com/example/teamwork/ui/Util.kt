package com.example.teamwork.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val localeId = Locale("id", "ID")

fun formatDay(millis: Long): String =
    SimpleDateFormat("EEEE, d MMMM yyyy", localeId).format(Date(millis))

fun formatDateTime(millis: Long): String =
    SimpleDateFormat("d MMM yyyy, HH:mm", localeId).format(Date(millis))

fun formatTime(millis: Long): String =
    SimpleDateFormat("HH:mm", localeId).format(Date(millis))

fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
    else -> String.format(localeId, "%.1f MB", bytes / (1024.0 * 1024.0))
}

/** Menampilkan dialog tanggal lalu jam bawaan Android, kemudian mengembalikan waktu dalam milidetik. */
fun pickDateTime(
    context: Context,
    initial: Long = System.currentTimeMillis(),
    onPicked: (Long) -> Unit
) {
    val cal = Calendar.getInstance().apply { timeInMillis = initial }
    DatePickerDialog(
        context,
        { _, year, month, day ->
            TimePickerDialog(
                context,
                { _, hour, minute ->
                    val picked = Calendar.getInstance().apply {
                        set(year, month, day, hour, minute, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    onPicked(picked.timeInMillis)
                },
                cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE),
                true
            ).show()
        },
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH),
        cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}
