package com.example.teamwork.data

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.Exclude

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val teamId: String = ""
)

data class Team(
    @DocumentId val id: String = "",
    val name: String = "",
    val code: String = "",
    val ownerUid: String = ""
)

enum class TaskStatus(val label: String) {
    OPEN("Akan dikerjakan"),
    DOING("Dikerjakan"),
    DONE("Selesai")
}

data class TeamTask(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val assignee: String = "",
    val status: String = TaskStatus.OPEN.name,
    val dueAt: Long = 0L,
    val createdBy: String = "",
    val createdAt: Long = 0L
) {
    @get:Exclude
    val statusEnum: TaskStatus
        get() = runCatching { TaskStatus.valueOf(status) }.getOrDefault(TaskStatus.OPEN)
}

data class TeamMessage(
    @DocumentId val id: String = "",
    val text: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val createdAt: Long = 0L
)

data class TeamEvent(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val startAt: Long = 0L,
    val createdBy: String = ""
)

data class TeamFile(
    @DocumentId val id: String = "",
    val name: String = "",
    val url: String = "",
    val storagePath: String = "",
    val size: Long = 0L,
    val uploadedBy: String = "",
    val createdAt: Long = 0L
)
