package com.example.teamwork.notify

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.teamwork.ui.formatTime
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

/**
 * Berjalan tiap ±15 menit (tanpa server) dan memberi pengingat untuk tugas
 * dan jadwal yang jatuh tempo dalam 1 jam ke depan.
 */
class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return Result.success()
        return try {
            val db = FirebaseFirestore.getInstance()
            val teamId = db.collection("users").document(uid).get().await().getString("teamId")
            if (teamId.isNullOrBlank()) return Result.success()

            val now = System.currentTimeMillis()
            val horizon = now + TimeUnit.HOURS.toMillis(1)
            val prefs = applicationContext.getSharedPreferences("reminders", Context.MODE_PRIVATE)
            val sent = prefs.getStringSet("sent", emptySet())!!.toMutableSet()
            if (sent.size > 500) sent.clear()
            val team = db.collection("teams").document(teamId)

            val tasks = team.collection("tasks")
                .whereGreaterThan("dueAt", now)
                .whereLessThanOrEqualTo("dueAt", horizon)
                .get().await()
            for (doc in tasks.documents) {
                if (doc.getString("status") == "DONE") continue
                val due = doc.getLong("dueAt") ?: continue
                val key = "t${doc.id}_$due"
                if (!sent.add(key)) continue
                Notifier.show(
                    applicationContext, Notifier.CH_REMINDERS,
                    "Tenggat tugas segera tiba",
                    "${doc.getString("title").orEmpty()} — pukul ${formatTime(due)}"
                )
            }

            val events = team.collection("events")
                .whereGreaterThan("startAt", now)
                .whereLessThanOrEqualTo("startAt", horizon)
                .get().await()
            for (doc in events.documents) {
                val start = doc.getLong("startAt") ?: continue
                val key = "e${doc.id}_$start"
                if (!sent.add(key)) continue
                Notifier.show(
                    applicationContext, Notifier.CH_REMINDERS,
                    "Jadwal segera dimulai",
                    "${doc.getString("title").orEmpty()} — pukul ${formatTime(start)}"
                )
            }

            prefs.edit().putStringSet("sent", sent).apply()
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "deadline_reminders"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<ReminderWorker>(15, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                )
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
