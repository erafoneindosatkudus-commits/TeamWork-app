# Model Firestore dibaca lewat refleksi; pertahankan jika isMinifyEnabled diaktifkan.
-keep class com.example.teamwork.data.** { *; }
