// Cloud Functions: mengirim notifikasi push (FCM) ke semua anggota tim
// lewat topik "team_<teamId>" saat ada pesan, tugas, atau jadwal baru.
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

function pushToTeam(teamId, data) {
  return getMessaging().send({
    topic: `team_${teamId}`,
    data,
    android: { priority: "high" },
  });
}

exports.onNewMessage = onDocumentCreated("teams/{teamId}/messages/{id}", (event) => {
  const m = event.data.data();
  return pushToTeam(event.params.teamId, {
    type: "chat",
    title: m.senderName || "Pesan baru",
    body: m.text || "",
    senderUid: m.senderUid || "",
  });
});

exports.onNewTask = onDocumentCreated("teams/{teamId}/tasks/{id}", (event) => {
  const t = event.data.data();
  return pushToTeam(event.params.teamId, {
    type: "task",
    title: "Tugas baru",
    body: `${t.createdBy || "Anggota"}: ${t.title || ""}`,
    senderUid: t.createdByUid || "",
  });
});

exports.onNewEvent = onDocumentCreated("teams/{teamId}/events/{id}", (event) => {
  const e = event.data.data();
  return pushToTeam(event.params.teamId, {
    type: "event",
    title: "Jadwal baru",
    body: `${e.createdBy || "Anggota"}: ${e.title || ""}`,
    senderUid: e.createdByUid || "",
  });
});
